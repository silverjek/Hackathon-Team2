from django.contrib import admin
from medicalinfo.models import *

# Register your models here.

admin.site.register(Medi_Info)
admin.site.register(Caution)
admin.site.register(Fam_History)
admin.site.register(Guardian)
admin.site.register(Info_Comment)